function Register() {
    return (
        <>
            <section>
                <h1>Register Page</h1>
            </section>
        </>
    )
}

export default Register
