function Dashboard() {
    return (
        <section>
            <h1>Dashboard Page</h1>
        </section>
    )
}

export default Dashboard
