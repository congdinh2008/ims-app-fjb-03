function Contact() {
    return (
        <section>
            <h1>Contact Page</h1>
        </section>
    )
}

export default Contact
